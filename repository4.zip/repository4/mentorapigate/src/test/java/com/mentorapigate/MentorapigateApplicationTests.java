package com.mentorapigate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentorapigateApplicationTests {

	@Test
	void contextLoads() {
	}

}
