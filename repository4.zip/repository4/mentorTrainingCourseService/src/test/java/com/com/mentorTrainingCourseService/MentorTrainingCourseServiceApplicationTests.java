package com.com.mentorTrainingCourseService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentorTrainingCourseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
