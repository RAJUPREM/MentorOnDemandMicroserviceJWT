package com.mentorOnDemandAuthenticationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentorOnDemandAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
